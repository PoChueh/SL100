/*
 * mcu_battery - MCU Battery Driver driver
 * Copyright (C) 2017 Joe Chen <joechen@axiomtek.com.tw>
 *
 * Based on the lm90 driver, with some ideas taken from the lm_sensors
 * lm92 driver as well.
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/power_supply.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <linux/vermagic.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>

/****************************Fucntion Prototypes*******************************/
static int mcu_detect(struct i2c_client * new_client, struct i2c_board_info * info);
static int mcu_probe(struct i2c_client * new_client, const struct i2c_device_id * id);
static int mcu_remove(struct i2c_client * client);

static int mcu_battery_get_property(struct power_supply * psy,
				    enum power_supply_property psp,
				    union power_supply_propval * val);
static int mcu_ac_get_property(struct power_supply * psy,
                               enum power_supply_property psp,
                               union power_supply_propval * val);
/****************************Battery Declaration*******************************/
/* Battery Props */
static enum power_supply_property mcu_battery_props[] = {
	POWER_SUPPLY_PROP_CAPACITY, // 0-100 %
	POWER_SUPPLY_PROP_PRESENT,  // true / false
	POWER_SUPPLY_PROP_STATUS,   // 1 for charging 0 for discharging
};

/* AC Supply Props*/
static enum power_supply_property mcu_ac_props[] = {
	POWER_SUPPLY_PROP_ONLINE,  // 1 for plugged in else 0
};

#define DEVICE_NAME "mcu_battery"
#define POWER_NUM 2
enum power_id {
        BATTERY,
        AC,
};

/* Hold Power Supply information*/
static struct power_supply * mcu_battery_supplies[POWER_NUM] = {NULL, NULL};

/* Description of the two power supplies */
static const struct power_supply_desc mcu_battery_desc[POWER_NUM] = {
        [BATTERY] = {
                .name = "BAT0",
                .type = POWER_SUPPLY_TYPE_BATTERY,
                .properties = mcu_battery_props,
                .num_properties = ARRAY_SIZE(mcu_battery_props),
                .get_property = mcu_battery_get_property,
        },
        [AC] = {
                .name = "AC",
                .type = POWER_SUPPLY_TYPE_MAINS,
                .properties = mcu_ac_props,
                .num_properties = ARRAY_SIZE(mcu_ac_props),
                .get_property = mcu_ac_get_property,
        },
};

/****************************I2C Declaration***********************************/
#define MCU_BATTERY_ADDRESS             0x46 /* MCU Battery Address */

/* The MCU Battery registers */
#define MCU_BATTERY_STATUS		        0x05 /* Byte, RO */
#define MCU_BATTERY_CHARGE_STATUS       0x08 /* Byte, RO */
#define MCU_BATTERY_CHARGE_LEVEL        0x11 /* Word, RO */
#define MCU_BATTERY_PRESENT             0x17 /* Word, RO */
#define MCU_BATTERY_VENDORID            0x80 /* Word, RO */
#define MCU_BATTERY_PRODUCTID           0x81 /* Word, RO */

#define MCU_BATTERY_VENDORID_VALUE      0x670D /* MCU Battery Vendor ID */
#define MCU_BATTERY_PRODUCTID_VALUE     0x525E /* MCU Battery Product ID */
/* List of possible MCU Addresses for the MCU*/
static const unsigned short mcu_address[] = { MCU_BATTERY_ADDRESS,
                                              I2C_CLIENT_END };

/* I2C Device information to register with kernel*/
static const struct i2c_device_id mcu_battery_id[] = {
	{ DEVICE_NAME, MCU_BATTERY_ADDRESS },
	{ }
};

MODULE_DEVICE_TABLE(i2c, mcu_battery_id);

/* Client data */
struct mcu_client_data {
	struct i2c_client * client; /* Pointer to Client Device */
	struct mutex update_lock; /* Mutex for thread protection */
	char valid; /* zero until following fields are valid */
};

/* Pointer to the struct that holds the client data */
struct mcu_client_data * mcuClient = NULL;


/* Struct holding information for the I2C chip information*/
static struct i2c_driver mcu_battery_driver = {
	.class		= I2C_CLASS_HWMON,
	.driver = {
		.name	= DEVICE_NAME,
	},
        .probe          = mcu_probe,
        .remove         = mcu_remove,
	.id_table	= mcu_battery_id,
        .detect         = mcu_detect,
        .address_list	= mcu_address,
};

/* Macro to create basic init and exit functions */
module_i2c_driver(mcu_battery_driver);

/****************************Battery Functions*********************************/
static int mcu_battery_get_property(struct power_supply *psy,
				    enum power_supply_property psp,
				    union power_supply_propval *val)
{
    int rVal = 0; /* Return Value */
    unsigned char tempValue = 0; /* Temp Holding Value */
    mutex_lock(&mcuClient->update_lock);
    switch (psp)
    {
        case POWER_SUPPLY_PROP_CAPACITY:
            val->intval = i2c_smbus_read_word_data(mcuClient->client, MCU_BATTERY_CHARGE_LEVEL);
            break;

        case POWER_SUPPLY_PROP_PRESENT:
            val->intval = i2c_smbus_read_word_data(mcuClient->client, MCU_BATTERY_PRESENT);
            break;

        case POWER_SUPPLY_PROP_STATUS:
            tempValue = i2c_smbus_read_byte_data(mcuClient->client, MCU_BATTERY_CHARGE_STATUS);
            /* Currently returns 0 for Discharging and 1 for Charging.  Maybe future add more states?*/
            val->intval = tempValue ? POWER_SUPPLY_STATUS_CHARGING : POWER_SUPPLY_STATUS_DISCHARGING;
            break;

        default:
            rVal = -EINVAL;
            break;
    }
    mutex_unlock(&mcuClient->update_lock);
    return rVal;
}

static int mcu_ac_get_property(struct power_supply *psy,
                               enum power_supply_property psp,
                               union power_supply_propval *val)
{
    int rVal = 0; /* Return Value */
    unsigned char tempValue = 0; /* Temp Holding Value */
    mutex_lock(&mcuClient->update_lock);
    switch (psp)
    {
        case POWER_SUPPLY_PROP_ONLINE:
            //Return 1 for battery 0 for AC
            tempValue = i2c_smbus_read_word_data(mcuClient->client, MCU_BATTERY_STATUS);
            val->intval = !tempValue; /* Value is inverted */
            break;

        default:
            rVal = -EINVAL;
            break;
    }
    mutex_unlock(&mcuClient->update_lock);
    return rVal;
}


/* Return 0 if successful, Error Otherwise*/
static int mcu_probe(struct i2c_client * new_client, const struct i2c_device_id * id )
{
    int rVal = 0; /* Return Value */
    int i = 0; /* Loop Iterator */
    mcuClient = devm_kzalloc(&new_client->dev, sizeof(struct mcu_client_data),
			    GFP_KERNEL);
    if (NULL == mcuClient)
    {
        rVal = -ENOMEM;
        pr_err("mcu_battery: Could not allocate memory \n");
    }
    else
    {
        mcuClient->client = new_client;
        mutex_init(&mcuClient->update_lock);
        for (i = 0; i < POWER_NUM && 0 == rVal; i++)
        {
            mcu_battery_supplies[i] = power_supply_register(&mcuClient->client->dev, &mcu_battery_desc[i], NULL);
            if (NULL == mcu_battery_supplies)
            {
                pr_err("%s: failed to register %s\n", __func__, mcu_battery_desc[i].name);
                rVal = -ENODEV;
                /* Unregister any batteries previously registered*/
                mcu_remove(mcuClient->client);
            }
        }
    }
    return rVal;
}

static int mcu_remove(struct i2c_client * client)
{
    int i = 0; /* Loop Iterator */
    for (i = 0; i < ARRAY_SIZE(mcu_battery_supplies); i++)
    {
        if (NULL != mcu_battery_supplies)
        {
            power_supply_unregister(mcu_battery_supplies[i]);
        }
    }
    return 0;
}

/* Return 0 if detection is successful, -ENODEV otherwise */
static int mcu_detect(struct i2c_client * new_client, struct i2c_board_info * info)
{
    int rVal = 0;
    struct i2c_adapter * adapter = new_client->adapter; // Get Head Adapter
    unsigned int vendorID = 0;
    unsigned int productID = 0;

    /* Make sure the adapter has the functions we need */
    if (!i2c_check_functionality(adapter, I2C_FUNC_SMBUS_BYTE_DATA
					  | I2C_FUNC_SMBUS_WORD_DATA))
    {
	rVal = -ENODEV;
    }
    else
    {
        // Check Product and Vendor ID
        vendorID = i2c_smbus_read_word_data(new_client, MCU_BATTERY_VENDORID);
        productID = i2c_smbus_read_word_data(new_client, MCU_BATTERY_PRODUCTID);

       	if (vendorID == MCU_BATTERY_VENDORID_VALUE && productID == MCU_BATTERY_PRODUCTID_VALUE)
        {
            pr_info("mcu_battery: Found device on %s\n", adapter->name);
            strlcpy(info->type, DEVICE_NAME, I2C_NAME_SIZE);
        }
        else
        {
            rVal = -ENODEV;
        }
    }
    return rVal;
}

MODULE_DESCRIPTION("DRE Battery driver for joechen");
MODULE_AUTHOR("Joe Chen <joechen@axiomtek.com.tw>");
MODULE_LICENSE("GPL");
